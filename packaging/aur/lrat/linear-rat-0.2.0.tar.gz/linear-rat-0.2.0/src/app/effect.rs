use jiff::Timestamp;

use super::{NewComment, NewIssue, TeamPoll, Write, Writing};
use crate::linear::{AnalyticsWindow, TeamQuery, Urgency};

/// A request to the outside world, returned by [`update`](super::update) and
/// carried out by the runtime.
#[derive(Debug, Clone, PartialEq)]
pub enum Effect {
    Quit,
    /// Restore the terminal, stop lrat until it is continued, then take the
    /// terminal back and draw the whole screen.
    Suspend,
    /// Load the viewer's open assigned issues; the result comes back as
    /// [`Event::MyIssuesLoaded`](super::Event::MyIssuesLoaded).
    LoadMyIssues,
    /// Load the comments and state history of the issue with this id; the
    /// result comes back as
    /// [`Event::IssueDetailLoaded`](super::Event::IssueDetailLoaded). Urgent
    /// when the viewer opened the detail, background when it only follows
    /// the list's focus.
    LoadIssueDetail {
        issue_id: String,
        urgency: Urgency,
    },
    /// Search the workspace for this term; the result comes back as
    /// [`Event::SearchDone`](super::Event::SearchDone).
    Search(String),
    /// Load the viewer's teams; the result comes back as
    /// [`Event::TeamsLoaded`](super::Event::TeamsLoaded).
    LoadTeams,
    /// Load what the filters of this team offer; the result comes back as
    /// [`Event::TeamOptionsLoaded`](super::Event::TeamOptionsLoaded).
    LoadTeamOptions(String),
    /// Load the page of `query`'s issues after the cursor `after`, or the
    /// first page; the result comes back as
    /// [`Event::TeamIssuesLoaded`](super::Event::TeamIssuesLoaded).
    LoadTeamIssues {
        query: TeamQuery,
        after: Option<String>,
    },
    /// Count every issue of the query; the result comes back as
    /// [`Event::TeamIssuesCounted`](super::Event::TeamIssuesCounted).
    CountTeamIssues(TeamQuery),
    /// Load what personal analytics needs for this window; the result comes
    /// back as [`Event::AnalyticsLoaded`](super::Event::AnalyticsLoaded).
    LoadAnalytics(AnalyticsWindow),
    /// Load the ids of the teams the viewer administers; the result comes
    /// back as
    /// [`Event::AdministrableTeamsLoaded`](super::Event::AdministrableTeamsLoaded).
    LoadAdministrableTeams,
    /// Load what team analytics needs for team `team_id` over `window`; the
    /// result comes back as
    /// [`Event::TeamAnalyticsLoaded`](super::Event::TeamAnalyticsLoaded).
    LoadTeamAnalytics {
        team_id: String,
        window: AnalyticsWindow,
    },
    /// Put this text on the system clipboard.
    Copy(String),
    /// Open this URL in the viewer's browser.
    OpenUrl(String),
    /// Ask each team for its issues changed since its watermark, one team
    /// after another; the result comes back as
    /// [`Event::Polled`](super::Event::Polled).
    Poll(Vec<TeamPoll>),
    /// Ask which of these issue ids still exist; the result comes back as
    /// [`Event::Reconciled`](super::Event::Reconciled).
    Reconcile(Vec<String>),
    /// Write the store to the snapshot cache.
    SaveSnapshot,
    /// Open Linear's websocket for the issues of these team ids and keep it
    /// open; each delivery comes back as
    /// [`Event::Live`](super::Event::Live). Asked for once, and only with
    /// `sync.live` on.
    GoLive(Vec<String>),
    /// Load a team's workflow states; the result comes back as
    /// [`Event::WorkflowStatesLoaded`](super::Event::WorkflowStatesLoaded).
    LoadWorkflowStates {
        team_id: String,
    },
    /// Load a team's members; the result comes back as
    /// [`Event::TeamMembersLoaded`](super::Event::TeamMembersLoaded).
    LoadTeamMembers {
        team_id: String,
    },
    /// Load the labels a team's issues can carry; the result comes back as
    /// [`Event::TeamLabelsLoaded`](super::Event::TeamLabelsLoaded).
    LoadTeamLabels {
        team_id: String,
    },
    /// Send one `issueUpdate` making [`Write::edit`]; the result comes back
    /// as [`Event::IssueUpdated`](super::Event::IssueUpdated).
    UpdateIssue(Write),
    /// Suspend the screen and open the viewer's `$EDITOR` on `text`; the
    /// buffer comes back as
    /// [`Event::EditorClosed`](super::Event::EditorClosed).
    OpenEditor {
        writing: Writing,
        text: String,
    },
    /// Send one `commentCreate`; the result comes back as
    /// [`Event::CommentCreated`](super::Event::CommentCreated).
    CreateComment(NewComment),
    /// Send one `issueCreate`; the result comes back as
    /// [`Event::IssueCreated`](super::Event::IssueCreated).
    CreateIssue(NewIssue),
    /// Read the issue's `updatedAt` again and, if it is still `seen`, send
    /// one `issueUpdate` making [`Write::edit`]; the result comes back as
    /// [`Event::IssueUpdated`](super::Event::IssueUpdated). If it moved,
    /// nothing is sent: `text`, the buffer as the viewer saved it, goes to a
    /// file only the viewer can read, and the error names that file.
    UpdateIssueText {
        write: Write,
        seen: Timestamp,
        text: String,
    },
}
