# Releasing

How I ship linear-rat, and the one-time setup that only I can do. Versions follow SemVer from `0.1.0`; while on `0.x`, a breaking change or a `feat` bumps the minor version (`features_always_increment_minor` in `release-plz.toml`) and a `fix` bumps the patch version. Each milestone lands on `main` as one squash-merged `feat`, so it ships as the next minor version.

## Pipeline

1. Every change lands on `main` as a squash-merged PR whose title is a Conventional Commit.
2. On each push to `main`, [release-plz](https://release-plz.dev) (`.github/workflows/release-plz.yml`, config in `release-plz.toml`) opens or updates a release PR: it bumps the version in `Cargo.toml` and `Cargo.lock` and writes `CHANGELOG.md` from the commits with git-cliff. `feat`, `fix`, `perf`, `revert`, `refactor` and `docs` commits get a changelog group; `build`, `chore`, `ci`, `style` and `test` commits are left out unless they are breaking. Only a `feat`, `fix`, `perf`, `refactor` or `revert` commit, or any breaking commit (`!` or a `BREAKING CHANGE:` footer), makes release-plz propose a new version (`release_commits`). A `docs`, `ci` or `chore` commit alone opens no release PR, even though the package includes `docs/` and `.github/`; it lands in the changelog of the next release.
3. Merging the release PR makes release-plz publish to crates.io through trusted publishing (OIDC, no stored token) and then create the `vX.Y.Z` tag through the GitHub API. It does not create the GitHub release (`git_release_enable = false`).
4. The `vX.Y.Z` tag triggers [dist](https://axodotdev.github.io/cargo-dist/book/) (`.github/workflows/release.yml`, config in `dist-workspace.toml`). It builds the four targets, creates the GitHub release with every asset attached, and then pushes the Homebrew formula to `cxrlos/homebrew-tap`.

Both release-plz jobs run with a GitHub App token, not `GITHUB_TOKEN`, because events made with `GITHUB_TOKEN` do not start workflows: without the App, CI would not run on the release PR and the tag would not trigger dist.

Targets: `x86_64-unknown-linux-gnu`, `aarch64-unknown-linux-gnu`, `x86_64-apple-darwin`, `aarch64-apple-darwin`. Linux and macOS only; Windows is not supported.

Each release carries one `.tar.xz` archive per target (the `lrat` binary, both licenses, `README.md`, `CHANGELOG.md`, and the completion scripts and man pages from `assets/` under `completions/` and `man/`) with its `.sha256`, `source.tar.gz`, `sha256.sum`, the shell installer `linear-rat-installer.sh` and the Homebrew formula `linear-rat.rb`. The install channels are:

```bash
cargo install --locked linear-rat
cargo binstall linear-rat
brew install cxrlos/tap/linear-rat
curl --proto '=https' --tlsv1.2 -LsSf \
  https://github.com/cxrlos/linear-rat/releases/latest/download/linear-rat-installer.sh \
  | sh
```

cargo-binstall finds the archives through `[package.metadata.binstall]` in `Cargo.toml`; dist itself has no binstall setting, so that table must keep matching dist's archive names.

## Immutable releases

Releases are immutable in this repo: once a release is published, its tag and assets cannot change. So exactly one tool, dist, creates the release, and it publishes it only after every asset is attached. I checked this against the docs and the pinned tool versions (release-plz 0.3.173, dist 0.32.0) in November 2026:

- GitHub locks a release's tag and assets when the release is published, and recommends creating it as a draft, attaching every asset, then publishing ([Immutable releases](https://docs.github.com/en/code-security/supply-chain-security/understanding-your-software-supply-chain/immutable-releases)).
- dist creates the release in its `host` job with a single `gh release create <tag> ... artifacts/*` call, after all build jobs succeed (`github-release = "host"`, `create-release` left at its default `true`; [dist config reference](https://axodotdev.github.io/cargo-dist/book/reference/config.html)). Nothing in the workflow uploads to the release afterwards; the Homebrew job only pushes to the tap.
- `gh release create` with assets creates a draft, uploads each asset, then publishes it, and refuses to run when a published release with that tag already exists ([gh release create](https://cli.github.com/manual/gh_release_create)). That is exactly GitHub's recommended order.
- With `git_release_enable = false`, release-plz creates the tag and no release ([release-plz config](https://release-plz.dev/docs/config)).
- The other dist mode, `create-release = false`, uploads into an existing draft and then undrafts it. I do not use it: nothing else creates a draft here.

What this means when something fails: if a build job fails, `host` never runs and no release exists, so a transient failure is fixed by rerunning the failed jobs for the same tag. If `gh release create` fails part-way, it deletes its own draft. By then the version is already on crates.io, so a failure that needs a code change, or a published release that is wrong, is fixed by the next patch version (see Rolling back).

## Changing the pipeline

`release.yml` is generated by dist. I never edit it by hand: the `plan` job, which also runs on every pull request, fails when the file differs from what `dist-workspace.toml` produces. To change it, I edit `dist-workspace.toml` and regenerate:

```bash
dist generate
dist plan
```

The actions in `release.yml` are pinned to commits, with a version comment, through `github-action-commits` in `dist-workspace.toml`; `actions/checkout` is the same commit `ci.yml` uses. Any change to `release.yml` that `dist generate` would not make breaks the release: the tag-time `plan` job runs `dist host`, which exits with "out of date contents" and leaves a version on crates.io with no GitHub release. Two guards keep that from happening. Dependabot skips `release.yml` (`exclude-paths` in `.github/dependabot.yml`), and the `plan` check is required on `main` (setup step 2), so a hand edit cannot merge. So Dependabot never updates these pins: when it bumps `actions/checkout` in the other workflows, I copy the new commit into `github-action-commits` and run `dist generate` in that PR, and I refresh `actions/upload-artifact` and `actions/download-artifact` the same way when I upgrade dist. To upgrade dist itself, I install the new version and run `dist init`, which rewrites `cargo-dist-version` and `release.yml`.

## One-time setup (manual)

Done: immutable releases, Discussions, wiki, delete branches on merge; Projects tab removed.

| # | What | Why |
|---|---|---|
| 1 | Repo settings: allow squash merge only, default the commit message to the PR title, delete branches on merge | Keeps `main` one Conventional Commit per PR, which release-plz reads |
| 2 | Branch protection (a ruleset) on `main`: require the CI checks and the `plan` check from `release.yml`, require linear history, block force pushes and deletion | Nothing reaches a release PR without passing CI, and a `release.yml` that dist did not generate cannot merge. Add it after CI exists, so the required check names are known |
| 2a | Security: enable private vulnerability reporting, Dependabot alerts and security updates, secret scanning with push protection | `SECURITY.md` and the issue chooser link to private advisories, which only works with private reporting on; `.github/dependabot.yml` already handles version updates |
| 3 | Create a GitHub App with repository permissions Contents: read and write, Pull requests: read and write; install it on this repo; store its App ID (or Client ID) as the secret `RELEASE_PLZ_APP_ID` and a private key as `RELEASE_PLZ_APP_PRIVATE_KEY` | With the default `GITHUB_TOKEN`, CI does not run on the release PR and the tag does not trigger dist. The workflow asks for a token scoped to exactly these permissions |
| 4 | Create the public repo `cxrlos/homebrew-tap` and a fine-grained PAT with `contents: write` on it, stored here as `HOMEBREW_TAP_TOKEN` | dist pushes the formula there |
| 5 | Publish `0.1.0` to crates.io by hand (see below) | crates.io cannot trusted-publish a crate that does not exist yet |
| 6 | On crates.io, add a trusted publisher for `linear-rat`: repo `cxrlos/linear-rat`, workflow `release-plz.yml`, no environment | Lets later releases publish with OIDC instead of a token |
| 7 | Revoke the API token used in step 5 | It is no longer needed |

## First release (0.1.0)

Work toward 0.1.0 is squash-merged into `main` from the `feat/v0.1.0` branch. Because `linear-rat` is not on crates.io yet, release-plz treats `0.1.0` as unreleased: after the first such merge it opens a release PR that keeps the version at `0.1.0` and adds `CHANGELOG.md`, and it updates that PR on every push to `main`. I leave that PR open until 0.1.0 is complete. Then:

1. From a clean `main`, publish by hand:

   ```bash
   cargo publish --dry-run --locked
   cargo publish --locked
   ```

2. Do setup steps 6 and 7.
3. Merge the release PR. The release job finds `0.1.0` already on crates.io and skips it, so it creates no tag. The release PR job opens no `0.1.1` PR: the published crate has no `CHANGELOG.md`, so release-plz sees the package changed, but the only new commit is `chore: release v0.1.0`, which `release_commits` does not match.
4. Tag the merge commit, so the release notes come from the new `CHANGELOG.md`:

   ```bash
   git switch main
   git pull --ff-only
   git tag v0.1.0
   git push origin v0.1.0
   ```

Pushing the tag runs dist and creates the GitHub release with binaries. After that, the next `feat`, `fix`, `perf`, `refactor`, `revert` or breaking commit on `main` opens the `0.1.1` (or `0.2.0`) release PR, and merging it publishes, tags and releases with no manual step.

I worked out steps 3 and 4 from release-plz 0.3.173's source (it skips a package whose tag exists or whose version is already published, and tags only after its own publish); they have not run live yet. I checked step 3's no-follow-up-PR claim with `release-plz update --registry-manifest-path` against a `0.1.0` packaged without `CHANGELOG.md`: it reports "no commit matches the `release_commits` regex" and changes nothing.

## AUR packages

`packaging/aur/` holds two Arch packages: `lrat-bin` installs the dist archive for `x86_64` or `aarch64`, and `lrat` builds the release's `source.tar.gz` with cargo. Both install the binary, both licenses, the completion scripts and the man pages. Nothing publishes them automatically. After each GitHub release, from a clean `main`, I bump both:

```bash
cd packaging/aur/lrat-bin
sed -i 's/^pkgver=.*/pkgver=X.Y.Z/; s/^pkgrel=.*/pkgrel=1/' PKGBUILD
updpkgsums
makepkg --printsrcinfo > .SRCINFO
makepkg -si
lrat --version
```

Then the same in `packaging/aur/lrat`. `updpkgsums` (from `pacman-contrib`) downloads the sources and writes their checksums; for `lrat-bin` they must equal the release's `linear-rat-<target>.tar.xz.sha256` files, and for `lrat` its `source.tar.gz.sha256`. `namcap PKGBUILD` and `namcap` on the built package should report no errors. I commit the bump here, then, from each package directory, push its `PKGBUILD` and `.SRCINFO` to its AUR repository:

```bash
git clone ssh://aur@aur.archlinux.org/lrat-bin.git /tmp/aur-lrat-bin
cp PKGBUILD .SRCINFO /tmp/aur-lrat-bin/
git -C /tmp/aur-lrat-bin commit -am "Update to X.Y.Z"
git -C /tmp/aur-lrat-bin push
```

The first push creates the AUR package, so it needs an AUR account with my SSH key; the first `git commit` there needs `git add PKGBUILD .SRCINFO` instead of `-a`. A packaging-only fix bumps `pkgrel` instead of `pkgver`. The completion scripts and man pages come from the archive (`completions/`, `man/`) and from `assets/` in the source, so the first version either package can build is the first release that ships them.

## Rolling back

A broken release is never deleted: I yank it with `cargo yank --version X.Y.Z linear-rat` and ship a fix as the next patch version. The version number of a yanked release is burned.
